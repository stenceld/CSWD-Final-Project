document.addEventListener("DOMContentLoaded", () => {
    const endDate = new Date("2024-12-31T23:59:59").getTime();
    
    function updateTimer() {
        const now = new Date().getTime();
        const timeLeft = endDate - now;
  
        if (timeLeft >= 0) {
            const days = Math.floor(timeLeft / (1000 * 60 * 60 * 24));
            const hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);
  
            document.getElementById("days").textContent = days;
            document.getElementById("hours").textContent = hours;
            document.getElementById("minutes").textContent = minutes;
            document.getElementById("seconds").textContent = seconds;
        } else {
            document.querySelector(".countdown-timer").innerHTML = `<h3>Offer Expired!</h3>`;
        }
    }
  
    setInterval(updateTimer, 1000);
  });
  
  
  document.addEventListener('DOMContentLoaded', () => {
    const shoeCards = document.querySelectorAll('.shoe-card');
  
    shoeCards.forEach(card => {
        card.addEventListener('click', () => {
            const url = card.getAttribute('data-url');
            if (url) {
                window.location.href = url;
            }
        });
    });
  });
  
// Cart storage
let cart = JSON.parse(localStorage.getItem('cart')) || [];

// Add to Cart logic
document.querySelectorAll('.buy-btn').forEach(button => {
    button.addEventListener('click', () => {
        const shoeCard = button.closest('.shoe-card');
        const shoeName = shoeCard.getAttribute('data-name');
        const shoePrice = parseFloat(shoeCard.getAttribute('data-price'));

        // Add item to cart array
        cart.push({ name: shoeName, price: shoePrice });
        
        // Save to localStorage
        localStorage.setItem('cart', JSON.stringify(cart));

        // Feedback to user
        alert(`${shoeName} has been added to the cart!`);
    });
});

// Display Cart Items on Checkout Page
function displayCartItems() {
    const cartContainer = document.querySelector('.order-summary ul');
    const totalPriceElem = document.getElementById('total-price');
    let total = 0;

    cartContainer.innerHTML = ''; // Clear cart container

    // Loop through cart and create list items
    cart.forEach(item => {
        total += item.price;
        const li = document.createElement('li');
        li.innerHTML = `
            <span class="item-name">${item.name}</span>
            <span class="item-price">$${item.price.toFixed(2)}</span>
        `;
        cartContainer.appendChild(li);
    });

    // Update total price
    totalPriceElem.textContent = `$${total.toFixed(2)}`;
}

// Call displayCartItems on checkout page load
if (document.querySelector('.order-summary')) {
    displayCartItems();
}
