document.addEventListener("DOMContentLoaded", () => {
  const endDate = new Date("2024-12-31T23:59:59").getTime();
  
  function updateTimer() {
      const now = new Date().getTime();
      const timeLeft = endDate - now;

      if (timeLeft >= 0) {
          const days = Math.floor(timeLeft / (1000 * 60 * 60 * 24));
          const hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
          const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
          const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);

          document.getElementById("days").textContent = days;
          document.getElementById("hours").textContent = hours;
          document.getElementById("minutes").textContent = minutes;
          document.getElementById("seconds").textContent = seconds;
      } else {
          document.querySelector(".countdown-timer").innerHTML = `<h3>Offer Expired!</h3>`;
      }
  }

  setInterval(updateTimer, 1000);
});

const cartBtn = document.getElementById("cart-btn");
const cartSection = document.getElementById("cart-section");
const cartOverlay = document.querySelector(".cart-overlay");

// Toggle cart visibility
cartBtn.addEventListener("click", (e) => {
  e.preventDefault();
  cartSection.classList.toggle("visible");
  cartOverlay.classList.toggle("visible");
});

// Close cart when clicking the overlay
cartOverlay.addEventListener("click", () => {
  cartSection.classList.remove("visible");
  cartOverlay.classList.remove("visible");
});

document.addEventListener('DOMContentLoaded', () => {
  const shoeCards = document.querySelectorAll('.shoe-card');

  shoeCards.forEach(card => {
      card.addEventListener('click', () => {
          const url = card.getAttribute('data-url');
          if (url) {
              window.location.href = url;
          }
      });
  });
});
