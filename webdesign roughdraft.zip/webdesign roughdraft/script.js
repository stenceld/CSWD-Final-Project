document.addEventListener("DOMContentLoaded", () => {
    const endDate = new Date("2024-12-31T23:59:59").getTime();

    function updateTimer() {
        const now = new Date().getTime();
        const timeLeft = endDate - now;

        if (timeLeft >= 0) {
            const days = Math.floor(timeLeft / (1000 * 60 * 60 * 24));
            const hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
            const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);

            document.getElementById("days").textContent = days;
            document.getElementById("hours").textContent = hours;
            document.getElementById("minutes").textContent = minutes;
            document.getElementById("seconds").textContent = seconds;
        } else {
            document.querySelector(".countdown-timer").innerHTML = `<h3>Offer Expired!</h3>`;
        }
    }

    setInterval(updateTimer, 1000);
});

// Cart storage
let cart = JSON.parse(localStorage.getItem('cart')) || [];

function updateCartCount() {
    const cartCountElement = document.querySelector("#cart-btn span");
    if (cartCountElement) {
        cartCountElement.textContent = cart.length; 
    }
}


document.querySelectorAll('.buy-btn').forEach(button => {
    button.addEventListener('click', () => {
        const shoeCard = button.closest('.shoe-card');
        const shoeName = shoeCard.getAttribute('data-name');
        const shoePrice = parseFloat(shoeCard.getAttribute('data-price'));

        cart.push({ name: shoeName, price: shoePrice });

        localStorage.setItem('cart', JSON.stringify(cart));

        updateCartCount();

        alert(`${shoeName} has been added to the cart!`);
    });
});


function displayCartItems() {
    const cartContainer = document.querySelector('.order-summary ul');
    const totalPriceElem = document.getElementById('total-price');
    let total = 0;

    cartContainer.innerHTML = ''; 

    cart.forEach(item => {
        total += item.price;
        const li = document.createElement('li');
        li.innerHTML = `
            <span class="item-name">${item.name}</span>
            <span class="item-price">$${item.price.toFixed(2)}</span>
        `;
        cartContainer.appendChild(li);
    });

   
    totalPriceElem.textContent = `$${total.toFixed(2)}`;
}


const clearCartBtn = document.getElementById("clear-cart-btn");
if (clearCartBtn) {
    clearCartBtn.addEventListener("click", () => {
        
        cart = [];
  
        localStorage.removeItem("cart");

        displayCartItems();

        updateCartCount();

        alert("Your cart has been cleared!");
    });
}


updateCartCount(); 
if (document.querySelector('.order-summary')) {
    displayCartItems();
}

document.querySelectorAll('.shoe-card').forEach(card => {
    card.addEventListener('click', () => {
        const url = card.getAttribute('data-url');
        if (url) {
            window.location.href = url;
        }
    });
});
