document.addEventListener("DOMContentLoaded", () => {
  const endDate = new Date("2024-12-31T23:59:59").getTime();
  
  function updateTimer() {
      const now = new Date().getTime();
      const timeLeft = endDate - now;

      if (timeLeft >= 0) {
          const days = Math.floor(timeLeft / (1000 * 60 * 60 * 24));
          const hours = Math.floor((timeLeft % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
          const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
          const seconds = Math.floor((timeLeft % (1000 * 60)) / 1000);

          document.getElementById("days").textContent = days;
          document.getElementById("hours").textContent = hours;
          document.getElementById("minutes").textContent = minutes;
          document.getElementById("seconds").textContent = seconds;
      } else {
          document.querySelector(".countdown-timer").innerHTML = `<h3>Offer Expired!</h3>`;
      }
  }

  setInterval(updateTimer, 1000);
});

// Show/Hide Login Modal
const loginBtn = document.getElementById('login-btn');
const loginModal = document.getElementById('login-modal');
const closeLogin = document.getElementById('close-login');

loginBtn.addEventListener('click', () => loginModal.classList.remove('hidden'));
closeLogin.addEventListener('click', () => loginModal.classList.add('hidden'));

// Show/Hide Cart Section
const cartBtn = document.getElementById('cart-btn');
const cartSection = document.getElementById('cart-section');

cartBtn.addEventListener('click', () => {
    cartSection.classList.toggle('hidden');
});

// Add Items to Cart (Example)
const cartItems = document.getElementById('cart-items');
cartBtn.addEventListener('click', () => {
    cartItems.innerHTML = `
        <li>Item 1 - $100</li>
        <li>Item 2 - $200</li>
    `;
});
