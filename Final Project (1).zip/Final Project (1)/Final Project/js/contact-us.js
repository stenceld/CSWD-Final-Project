document.addEventListener('DOMContentLoaded', () => {
    // Regular contact form
    const form = document.getElementById('contact-form');
    const emailInput = document.getElementById('email');
    const messageDiv = document.getElementById('message');

    // Business inquiry form
    const businessForm = document.getElementById('business-form');
    const businessEmailInput = document.getElementById('business-email');
    const businessMessageDiv = document.getElementById('business-message');

    // Handle regular contact form
    form.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const email = emailInput.value.trim();
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        
        // Clear the email input
        emailInput.value = '';
        
        if (!emailRegex.test(email)) {
            messageDiv.textContent = 'Invalid Email';
            messageDiv.style.color = 'Red';
        } else {
            messageDiv.textContent = 'Successful';
            messageDiv.style.color = 'Green';
        }
    });

    // Handle business inquiry form
    businessForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        const email = businessEmailInput.value.trim();
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        
        // Clear the email input
        businessEmailInput.value = '';
        
        if (!emailRegex.test(email)) {
            businessMessageDiv.textContent = 'Invalid Email';
            businessMessageDiv.style.color = 'Red';
        } else {
            businessMessageDiv.textContent = 'Successful';
            businessMessageDiv.style.color = 'Green';
        }
    });
});